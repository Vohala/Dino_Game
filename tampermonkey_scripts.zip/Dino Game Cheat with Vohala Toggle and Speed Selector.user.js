// ==UserScript==
// @name         Dino Game Cheat with Vohala Toggle and Speed Selector
// @namespace    http://tampermonkey.net/
// @version      1.8
// @description  Cheat for Google Chrome Dinosaur Game (Vohala toggle and adjustable speed)
// @author       Your Name
// @match        *://*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    if (document.getElementsByClassName('runner-canvas').length > 0) {
        console.log('Dino game detected. Activating Vohala toggle and speed selector...');

        let cheatEnabled = true;
        let speedMultiplier = 1; // Default speed is normal
        let originalGameOver = Runner.prototype.gameOver;
        let originalSetSpeed = null; // To store the original setSpeed method
        let originalSpeed = null; // To store the original game speed

        // Enable invincibility cheat
        function enableCheat() {
            Runner.prototype.gameOver = function() {
                console.log('Collision detected, but Vohala cheat is active. No game over!');
            };
            console.log('Vohala cheat enabled: Dino is invincible.');
        }

        // Disable invincibility cheat
        function disableCheat() {
            Runner.prototype.gameOver = originalGameOver;
            console.log('Vohala cheat disabled: Dino can lose now.');
        }

        // Apply selected speed to the game
        function applyGameSpeed() {
            const runnerInstance = Runner.instance_;
            if (runnerInstance) {
                if (speedMultiplier === 1) {
                    // Restore original speed behavior
                    runnerInstance.setSpeed = originalSetSpeed;
                    runnerInstance.setSpeed(originalSpeed); // Reset to original speed
                } else {
                    // Override setSpeed to apply multiplier
                    runnerInstance.setSpeed = (function(originalSetSpeed) {
                        return function(speed) {
                            originalSetSpeed.call(this, speed * speedMultiplier);
                        };
                    })(originalSetSpeed);
                    runnerInstance.setSpeed(originalSpeed); // Apply the current speed immediately
                }
                console.log(`Game speed set to ${speedMultiplier}x.`);
            }
        }

        // Add a toggle button to the screen
        function addToggleButton() {
            let button = document.createElement('button');
            button.id = 'vohala-toggle-button';
            button.style.position = 'fixed';
            button.style.top = '10px';
            button.style.right = '10px';
            button.style.zIndex = '9999';
            button.style.padding = '10px 20px';
            button.style.backgroundColor = '#4CAF50';
            button.style.color = 'white';
            button.style.border = 'none';
            button.style.borderRadius = '5px';
            button.style.cursor = 'pointer';
            button.innerHTML = 'Vohala Enable';

            button.addEventListener('click', function() {
                cheatEnabled = !cheatEnabled;
                if (cheatEnabled) {
                    enableCheat();
                    button.style.backgroundColor = '#4CAF50';
                    button.innerHTML = 'Vohala Enable';
                } else {
                    disableCheat();
                    button.style.backgroundColor = '#f44336';
                    button.innerHTML = 'Vohala Disable';
                }
            });

            document.body.appendChild(button);
        }

        // Add a dropdown menu to select speed
        function addSpeedDropdown() {
            let dropdown = document.createElement('select');
            dropdown.id = 'vohala-speed-selector';
            dropdown.style.position = 'fixed';
            dropdown.style.top = '50px';
            dropdown.style.right = '10px';
            dropdown.style.zIndex = '9999';
            dropdown.style.padding = '5px';
            dropdown.style.border = '1px solid #ccc';
            dropdown.style.borderRadius = '5px';
            dropdown.style.cursor = 'pointer';
            dropdown.style.backgroundColor = '#4CAF50';
            dropdown.style.color = 'white';
            dropdown.style.fontWeight = 'bold';

            // Add a label to the dropdown
            let dropdownLabel = document.createElement('option');
            dropdownLabel.disabled = true;
            dropdownLabel.selected = true;
            dropdownLabel.textContent = 'Vohala Speed Dropdown';
            dropdown.appendChild(dropdownLabel);

            // Speed options
            const speeds = [
                { label: 'Normal Speed', value: 1 },
                { label: '5x Speed', value: 5 },
                { label: '75x Speed', value: 75 },
                { label: '400x Speed', value: 400 },
                { label: '850x Speed', value: 850 },
                { label: '1200x Speed', value: 1200 }
            ];

            speeds.forEach(speed => {
                let option = document.createElement('option');
                option.value = speed.value;
                option.textContent = speed.label;
                dropdown.appendChild(option);
            });

            dropdown.addEventListener('change', function() {
                speedMultiplier = parseFloat(this.value);
                applyGameSpeed();
                console.log(`Speed changed to: ${this.options[this.selectedIndex].text}`);
            });

            document.body.appendChild(dropdown);
        }

        // Initialize the cheat
        function initialize() {
            const runnerInstance = Runner.instance_;
            if (runnerInstance) {
                originalSetSpeed = runnerInstance.setSpeed; // Store original setSpeed method
                originalSpeed = runnerInstance.currentSpeed; // Store original speed
                addToggleButton();
                addSpeedDropdown();
                enableCheat();
                applyGameSpeed();
            }
        }

        initialize();
    } else {
        console.log('Dino game not detected. This script only works on the Dino game.');
    }
})();
